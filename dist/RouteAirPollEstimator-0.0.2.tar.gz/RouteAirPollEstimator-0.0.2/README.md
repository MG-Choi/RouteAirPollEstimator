# RouteAirPollEstimator
A library for estimating spatial-temporal air pollution exposure amounts by dividing routes.
